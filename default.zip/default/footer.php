<!-- =======公共======= -->

<script src="/{$template_catalog}/template/{$public_themes}/js/common/axios.min.js"></script>
<script src="/{$template_catalog}/template/{$public_themes}/utils/request.js"></script>
<script src="/{$template_catalog}/template/{$public_themes}/api/common.js"></script>
<script src="/{$template_catalog}/template/{$public_themes}/components/asideMenu/asideMenu.js"></script>
<script src="/{$template_catalog}/template/{$public_themes}/components/topMenu/topMenu.js"></script>
<script src="/{$template_catalog}/template/{$public_themes}/utils/directive.js"></script>

</body>

</html>
